﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public static class Adm
    {
        public static string nomeadm = "administrador";
        public static string senhaadm = "pigeon";
        
        
    }
}
