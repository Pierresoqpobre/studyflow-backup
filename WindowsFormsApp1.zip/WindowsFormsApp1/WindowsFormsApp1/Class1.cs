﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    static public class Nomeusuario
    {
        public static string [] nomes = new string[250];
        public static string [] senhas = new string[250];
        public static string[] logados = new string[250];
        public static int contador = 0;


    }

    }

